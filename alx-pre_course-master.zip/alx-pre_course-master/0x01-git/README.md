reademe for 0x01-git
